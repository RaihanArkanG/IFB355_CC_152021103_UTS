import 'package:flutter/material.dart';
import 'sidebar.dart';
import 'Addition/constants.dart';
import 'calculator_page.dart'; // Import your Calculator page
import 'bmi_calculator.dart'; // Import your BMI Calculator page
import 'biodata_page.dart';
import 'graph_page.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  PageController _pageController = PageController();

  @override
  Widget build(BuildContext context) {
    double buttonHeight = MediaQuery.of(context).size.height * 0.25 / 2;

    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
        backgroundColor: primaryButtonColor,
      ),
      drawer: SideBar(),
      body: Container(
        height: MediaQuery.of(context).size.height * 0.25,
        child: PageView(
          controller: _pageController,
          children: [
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      SizedBox(
                        height: buttonHeight,
                        child: ElevatedButton.icon(
                          onPressed: () {
                            // Navigate to Calculator page
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => CalculatorPage()),
                            );
                          },
                          icon: Icon(
                            Icons.calculate,
                            size: 60, // Adjust the icon size as needed
                          ),
                          label: Text('Calculator'), // Add a label to the button
                        ),
                      ),
                      SizedBox(
                        height: buttonHeight,
                        child: ElevatedButton.icon(
                          onPressed: () {
                            // Navigate to BMI Calculator page
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => BMICalculatorPage()),
                            );
                          },
                          icon: Icon(
                            Icons.accessibility,
                            size: 60, // Adjust the icon size as needed
                          ),
                          label: Text('BMI Calculator'), // Add a label to the button
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      SizedBox(
                        height: buttonHeight,
                        child: ElevatedButton.icon(
                          onPressed: () {
                            // Navigate to Graph page
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => GraphPage()),
                            );
                          },
                          icon: Icon(
                            Icons.insert_chart,
                            size: 60, // Adjust the icon size as needed
                          ),
                          label: Text('Graph'), // Add a label to the button
                        ),
                      ),
                      SizedBox(
                        height: buttonHeight,
                        child: ElevatedButton.icon(
                          onPressed: () {
                            // Navigate to Biodata page
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => BiodataPage()),
                            );
                          },
                          icon: Icon(
                            Icons.person,
                            size: 60, // Adjust the icon size as needed
                          ),
                          label: Text('Biodata'), // Add a label to the button
                        ),
                      ),

                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}