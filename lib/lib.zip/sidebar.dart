import 'package:flutter/material.dart';
import 'Addition/constants.dart';
import 'calculator_page.dart';
import 'bmi_calculator.dart';
import 'graph_page.dart';
import 'setting_page.dart';
import 'biodata_page.dart';
import 'login_page.dart';

class SideBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          UserAccountsDrawerHeader(
            accountName: Text('raihan'), // Display user name
            accountEmail: Text('email@example.com'), // Display user email
            currentAccountPicture: CircleAvatar(
              backgroundImage: AssetImage("assets/profile.jpeg"),
            ),
            decoration: BoxDecoration(
              color: primaryButtonColor,
            ),
          ),
          ListTile(
            title: Text('Calculator', style: textTextStyle),
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(builder: (context) => CalculatorPage()));
            },
          ),
          ListTile(
            title: Text('BMI Calculator', style: textTextStyle),
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(builder: (context) => BMICalculatorPage()));
            },
          ),
          ListTile(
            title: Text('Graph', style: textTextStyle),
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(builder: (context) => GraphPage()));
            },
          ),
          ListTile(
            title: Text('Biodata', style: textTextStyle),
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(builder: (context) => BiodataPage()));
            },
          ),
          ListTile(
            title: Text('Settings', style: textTextStyle),
            onTap: () async {
              // Navigate to the SettingsPage and wait for the result
              await Navigator.of(context).push(MaterialPageRoute(
                builder: (context) => SettingsPage(),
              ));
            },
          ),
          ListTile(
            title: Text('About', style: textTextStyle),
            onTap: () {
              // Navigate to the about page
            },
          ),
          Divider(), // Add a divider to separate items
          ListTile(
            title: Text('Logout', style: textTextStyle),
            onTap: () {
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => LoginPage()));
            },
          ),
        ],
      ),
    );
  }
}
